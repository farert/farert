//
//  main.m
//  alps_ios
//
//  Created by TAKEDA, Noriyuki on 2014/06/09.
//  Copyright (c) 2014年 TAKEDA, Noriyuki. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int g_tax = 8;

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
