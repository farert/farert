//
//  SelectLineTableViewController.h
//  alps_ios
//
//  Created by TAKEDA, Noriyuki on 2014/07/27.
//  Copyright (c) 2014年 TAKEDA, Noriyuki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectLineTableViewController : UITableViewController
// in
@property NSInteger companyOrPrefectId;
@property NSInteger baseStationId;
@property NSInteger lastLineId;

@end
