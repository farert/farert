//
//  ResultTableViewController.m
//  alps_ios
//
//  Created by TAKEDA, Noriyuki on 2014/07/21.
//  Copyright (c) 2014年 TAKEDA, Noriyuki. All rights reserved.
//

#import "ResultTableViewController.h"
#import "RouteDataController.h"
#import "FareInfo.h"

#define DISABLE (-1)

@interface ResultTableViewController ()
{
    NSInteger num_of_km;
    NSInteger num_of_fare;
    NSMutableArray* contentsForKm;
    NSMutableArray* contentsForFare;
    NSInteger specificApply;    // 0:disable 1:apply 2:no apply
    NSInteger areaTerminal;     // 0:disable 1:発駅適用 2:着駅適用
}
// メールビュー生成
@property (strong, nonatomic) MFMailComposeViewController* mailViewCtl;

@property (strong, nonatomic) FareInfo* fareInfo;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *actionBarButton;
#if 0
@property (weak, nonatomic) IBOutlet UIBarButtonItem *specificAppliedBarButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *areaTerminalBarButton;
#endif

@property (nonatomic, strong) UIView *frontView;
@property (nonatomic, strong) UIActivityIndicatorView *indicator;

@end

@implementation ResultTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    //[self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(preferredContentSizeChanged:)
                                                 name:UIContentSizeCategoryDidChangeNotification
                                               object:nil];

    //NSLog(@"ResultView didLoad entry");
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.navigationController.toolbarHidden = NO;

    // Inner state variables
    ///self.specificAppliedBarButton.enabled = YES;
    specificApply = RULE_APPLIED;

    // Calculate of fare.
    _fareInfo = [_ds calcFare:RULE_APPLIED];

    if (!_fareInfo || _fareInfo.result != 0) {
        return;
    } else {
        // 発(着)駅を単駅にボタン設定
        [self specificButtonTitleChange];
    }
    self.navigationItem.title = [RouteDataController TerminalName:_fareInfo.endStationId];
    self.navigationItem.prompt = [[RouteDataController TerminalName:_fareInfo.beginStationId] stringByAppendingString:@" → "];
    
    [self setupDispContent];
    
    self.tableView.sectionHeaderHeight = 40.0;
    self.tableView.sectionFooterHeight = 0.01;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSLog(@"memory war in result view");
}

// 戻ってきたときにセルの選択を解除
- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:NO];
}

- (void)preferredContentSizeChanged:(NSNotification *)aNotification
{
    // refresh tableView
    [self.tableView reloadData];
}


// xToolbar : 結果メール送信ボタン
// action sheet
- (IBAction)actionBarButtonAction:(id)sender
{
    UIActionSheet *actsheet = [[UIActionSheet alloc] init];
    UIWindow* window = [[[UIApplication sharedApplication] delegate] window];
    
    actsheet.delegate = self;
    actsheet.title = self.title;
    if ([MFMailComposeViewController canSendMail]) {
        [actsheet addButtonWithTitle:@"メール送信"];
    } else {
        [actsheet addButtonWithTitle:@"メール送信できません"];
    }
    if (specificApply == RULE_APPLIED ) {
        [actsheet addButtonWithTitle:@"特例を適用しない"];
        if (areaTerminal == APPLIED_TERMINAL) {
            [actsheet addButtonWithTitle:@"着駅を単駅指定"];
        } else if (areaTerminal == APPLIED_START) {
            [actsheet addButtonWithTitle:@"発駅を単駅指定"];
        }
    } else if (specificApply == RULE_NO_APPLIED) {
        [actsheet addButtonWithTitle:@"特例を適用する"];
    }
    if (_fareInfo.isArbanArea) {
        [actsheet addButtonWithTitle:@"最短経路算出"];
    }
    [actsheet addButtonWithTitle:@"キャンセル"];
    actsheet.cancelButtonIndex = [actsheet numberOfButtons] - 1;
    if (![MFMailComposeViewController canSendMail]) {
        actsheet.destructiveButtonIndex = 0;    /* Can't send mail (Red color title) */
    }
    if ([window.subviews containsObject:self.tableView]) {
        [actsheet showInView:self.tableView];
    } else {
        [actsheet showInView:window];
    }
}



// FareInfo 再計算
- (void)reCalcFareInfo
{
    if (!_fareInfo || _fareInfo.result != 0) {
        return;   // Error message
    }
    
    NSInteger cookedFlag = [self retrieveCalcParameter];
    _fareInfo = [_ds calcFare:cookedFlag];
    [self specificButtonTitleChange];

    self.navigationItem.title = [RouteDataController TerminalName:_fareInfo.endStationId];
    self.navigationItem.prompt = [[RouteDataController TerminalName:_fareInfo.beginStationId] stringByAppendingString:@" → "];

    // refresh tableView
    [self setupDispContent];
    [self.tableView reloadData];
}

// Retrieve the calculate parameter
//
- (NSInteger)retrieveCalcParameter
{
    int cookedFlag = RULE_APPLIED; //=0

    if (DISABLE != specificApply) {
        if (RULE_NO_APPLIED == specificApply) {
            cookedFlag = RULE_NO_APPLIED;   // 特例非適用
        }
    }

    if (DISABLE != areaTerminal) {
        if (areaTerminal == APPLIED_START) {
            cookedFlag |= APPLIED_START;
        }
    }
    return cookedFlag;
}


// 計算結果より発駅／着駅単駅切り替えが有効かを設定
//
- (void)specificButtonTitleChange
{
    if (!_fareInfo || _fareInfo.result != 0) {
        return;   // Error message
    }

    if (_fareInfo.calcResultFlag == 1) {
        // 発駅=都区市内
        areaTerminal = APPLIED_START;
        ///self.areaTerminalBarButton.title = @"発駅を単駅に";
        ///self.areaTerminalBarButton.enabled = YES;
        
    } else if (_fareInfo.calcResultFlag == 2) {
        // 着駅=都区市内
        areaTerminal = APPLIED_TERMINAL;
        ///self.areaTerminalBarButton.title = @"着駅を単駅に";
        ///self.areaTerminalBarButton.enabled = YES;
        
    } else {
        areaTerminal = DISABLE;
        ///self.areaTerminalBarButton.enabled = NO;
    }
}

//  Action Sheet (Send mail)
//
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //NSLog(@"action select:%d", buttonIndex);
    NSString* title;

    if ((actionSheet.numberOfButtons - 1) == buttonIndex) {
        return; // Canceled
    }

    // Send mail
    title = [actionSheet buttonTitleAtIndex:buttonIndex];
    if ([title rangeOfString:@"メール"].location != NSNotFound) {
        // send mail
        [self sendResultMail];
    } else if ([title rangeOfString:@"特例"].location != NSNotFound) {
        if (specificApply == RULE_APPLIED ) {
            // @"特例を適用しない";
            specificApply = RULE_NO_APPLIED;
            [self reCalcFareInfo];
            
        } else if (specificApply == RULE_NO_APPLIED) {
            // @"特例を適用する";
            specificApply = RULE_APPLIED;
            [self reCalcFareInfo];
            
        } else {
            NSAssert(Nil, @"bug");
        }
    } else if ([title rangeOfString:@"単駅"].location != NSNotFound) {
        // "発駅を単駅指定";
        if (areaTerminal == APPLIED_TERMINAL) {
            areaTerminal = APPLIED_START;
            [self reCalcFareInfo];
            
        } else if (areaTerminal == APPLIED_START) {
            // "発駅を単駅指定";
            areaTerminal = APPLIED_TERMINAL;
            [self reCalcFareInfo];
        }
    } else if ([title rangeOfString:@"最短経路"].location != NSNotFound) {
        [self showIndicate];
        self.navigationController.view.userInteractionEnabled = NO;
        [self performSelector:@selector(processDuringIndicatorAnimating:)
                   withObject:Nil
                   afterDelay:0.1];
    } else {
        // cancel
    }
}

//  長い処理
//
- (void)processDuringIndicatorAnimating:(id)param
{
    NSInteger rc;
    NSInteger begin_id;
    NSInteger end_id;
    
    begin_id = [_ds startStationId];
    end_id = [_ds lastStationId];
    [_ds resetStartStation];
    [_ds addRoute:begin_id];
    rc = [_ds autoRoute:FALSE arrive:end_id];
    if (0 <= rc) {
        [self reCalcFareInfo];
    }
    [self hideIndicate];    /* hide Activity and enable UI */
}

#pragma mark - Table view data source

//  Table section
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    if (_fareInfo && _fareInfo.result == 0) {
        return 5;
    } else {
        return 1;
    }
}

//  Table section
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (!_fareInfo || _fareInfo.result != 0) {
        return 1;   // Error message
    }
    switch (section) {
        case 0:
            return 1; /* section */
            break;
        case 1:
            return num_of_km; /* sales, calc km */
        case 2:
            return num_of_fare; /* Fare */
            break;
        case 3:         /* avail days */
        case 4:         /* route list */
            return 1;
            break;
        default:
            break;
    }
    return 0;
}

//
//
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (!_fareInfo || _fareInfo.result != 0) {
        return @"無効な経路";   // Error message
    }
    switch (section) {
        case 0:
            return @"区間"; /* section */
            break;
        case 1:
            return @"キロ程"; /* sales, calc km */
        case 2:
            return @"運賃"; /* Fare */
            break;
        case 3:
            return @"有効日数";
            break;
        case 4:
            return @"経由";  /* route list */
            break;
        default:
            break;
    }
    return nil;
}

//
//
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = nil;
    UILabel* lbl = nil;
    NSDictionary* dic = nil;
    NSString* str = nil;

    if (!_fareInfo || (_fareInfo.result != 0)) {    // error
        cell = [tableView dequeueReusableCellWithIdentifier:@"rsRouteListCell" forIndexPath:indexPath];
        //lbl = (UILabel*)[cell viewWithTag:1];
        //lbl.text = [_fareInfo routeList];
        cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        cell.textLabel.numberOfLines = 0;
        if (!_fareInfo) {
            cell.textLabel.text = @"経路が空";
        } else {
            switch (_fareInfo.result) {
            case 1:
                cell.textLabel.text = @"経路が不完全のため運賃は表示できません";
                break;
            case 2:
                cell.textLabel.text = @"会社線のみ運賃は表示できません";
                break;
            default:
                cell.textLabel.text = @"運賃は表示できません";
                break;
            }
        }
        cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        cell.textLabel.numberOfLines = 0;
        return cell;   // Error message
    }

    switch ([indexPath section]) {
        case 0:
            /* section */
            cell = [tableView dequeueReusableCellWithIdentifier:@"rsTitleCell" forIndexPath:indexPath];
            lbl = (UILabel*)[cell viewWithTag:1];
            lbl.text = [NSString stringWithFormat:@"%@ → %@", [RouteDataController TerminalName:_fareInfo.beginStationId],[RouteDataController TerminalName:_fareInfo.endStationId]];
            break;
        case 1:
            /* KM */
            dic = [contentsForKm objectAtIndex:indexPath.row];
            
            if ([indexPath row] == 0) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"rsKmCell1" forIndexPath:indexPath];
                lbl = (UILabel*)[cell viewWithTag:2];
                lbl.text = dic[@"salesKm"];
                str = dic[@"calcKm"];
                if (0 < [str length]) {
                    lbl = (UILabel*)[cell viewWithTag:3];
                    lbl.text = dic[@"subTitle"];
                    lbl = (UILabel*)[cell viewWithTag:4];
                    lbl.text = str;
                } else {
                    lbl = (UILabel*)[cell viewWithTag:3];
                    lbl.text = @"";
                    lbl = (UILabel*)[cell viewWithTag:4];
                    lbl.text = @"";
               }
            } else {
                if (!dic[@"Company_salesKm"]) {
                    cell = [tableView dequeueReusableCellWithIdentifier:@"rsKmCell2" forIndexPath:indexPath];
                    lbl = (UILabel*)[cell viewWithTag:1];
                    lbl.text = dic[@"title"];
                    lbl = (UILabel*)[cell viewWithTag:2];
                    lbl.text = dic[@"salesKm"];
                    str = dic[@"calcKm"];
                    lbl = (UILabel*)[cell viewWithTag:4];
                    if (0 < [str length]) {
                        lbl.text = str;
                    } else {
                        lbl.text = @"";
                    }
                } else {
                    cell = [tableView dequeueReusableCellWithIdentifier:@"rsKmCell3" forIndexPath:indexPath];
                    lbl = (UILabel*)[cell viewWithTag:2];
                    lbl.text = dic[@"JR_salesKm"];
                    lbl = (UILabel*)[cell viewWithTag:4];
                    lbl.text = dic[@"Company_salesKm"];
                }
            }
            break;
        case 2:
            /* FARE */
            dic = [contentsForFare objectAtIndex:indexPath.row];

            if ([indexPath row] == 0) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"rsFareCell" forIndexPath:indexPath];
                lbl = (UILabel*)[cell viewWithTag:2];
                lbl.text = dic[@"fare"];
                lbl = (UILabel*)[cell viewWithTag:3];
                lbl.text = dic[@"subTitle"];
                lbl = (UILabel*)[cell viewWithTag:4];
                lbl.text = dic[@"subFare"]; /* company or IC */
                
            } else if ([indexPath row] == 1) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"rsFareCell2" forIndexPath:indexPath];
                lbl = (UILabel*)[cell viewWithTag:2];
                lbl.text = dic[@"fare"];
                lbl = (UILabel*)[cell viewWithTag:4];
                lbl.text = dic[@"subFare"];
            } else {
                cell = [tableView dequeueReusableCellWithIdentifier:@"rsDiscountFareCell" forIndexPath:indexPath];
                lbl = (UILabel*)[cell viewWithTag:1];
                lbl.text = dic[@"title"];
                lbl = (UILabel*)[cell viewWithTag:2];
                lbl.text = dic[@"fare"];
            }
            break;
        case 3:
            /* avail days */
            if (!_fareInfo.isArbanArea) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"rsAvailDaysCell" forIndexPath:indexPath];
                lbl = (UILabel*)[cell viewWithTag:1];
                lbl.text = [NSString stringWithFormat:@"%ld日間", (long)_fareInfo.ticketAvailDays];
                lbl = (UILabel*)[cell viewWithTag:2];
                if (1 < _fareInfo.ticketAvailDays) {
                    if (_fareInfo.isBeginInCiry && _fareInfo.isEndInCiry) {
                        str = @"(発着駅都区市内の駅を除き";
                    } else if (_fareInfo.isBeginInCiry) {
                        str = @"(発駅都区市内の駅を除き";
                    } else if (_fareInfo.isEndInCiry) {
                        str = @"(着駅都区市内の駅を除き";
                    } else {
                        str = @"(";
                    }
                    lbl.text = [str stringByAppendingString:@"途中下車可能)"];
                } else {
                    lbl.text = @"(途中下車前途無効)";
                }
            } else {
                cell = [tableView dequeueReusableCellWithIdentifier:@"rsMetroAvailDaysCell" forIndexPath:indexPath];
            }
            break;
        case 4:
            /* ROUTE */
            cell = [tableView dequeueReusableCellWithIdentifier:@"rsRouteListCell" forIndexPath:indexPath];
            //lbl = (UILabel*)[cell viewWithTag:1];
            //lbl.text = [_fareInfo routeList];
            cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
            cell.textLabel.numberOfLines = 0;
            cell.textLabel.text = [_fareInfo routeList];
            break;
        default:
            break;
    }    
    return cell;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - Table view delegate
#if 0
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30.0;
}
#endif

//  行の高さ
//
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString* ident = nil;
    NSString* text = nil;
    UIFont *nameLabelFont = nil;
    CGFloat PADDING_OUTER = 30;
    CGRect totalRect;
    NSDictionary* dic = nil;
    
    switch ([indexPath section]) {
        case 0:
            /* section */
            ident = @"rsTitleCell";
            break;
        case 1:
            /* KM */
            if ([indexPath row] == 0) {
                ident = @"rsKmCell1";
            } else {
                dic = [contentsForKm objectAtIndex:indexPath.row];
                if (!dic[@"Company_salesKm"]) {
                    ident = @"rsKmCell2";
                } else {
                    ident = @"rsKmCell3";
                }
            }
            break;
        case 2:
            /* FARE */
            if ([indexPath row] == 0) {
                ident = @"rsFareCell";
            } else if ([indexPath row] == 1) {
                ident = @"rsFareCell2";
            } else {
                ident = @"rsDiscountFareCell";
            }
            break;
        case 3:
            /* avail days */
            if (!_fareInfo.isArbanArea) {
                ident = @"rsAvailDaysCell";
            } else {
                ident = @"rsMetroAvailDaysCell";
            }
            break;
        case 4:
            /* ROUTE */
            text = [_fareInfo routeList];
            nameLabelFont = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
            
            totalRect = [text boundingRectWithSize:CGSizeMake(self.tableView.frame.size.width, CGFLOAT_MAX)
                                                  options:(NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading)
                                               attributes:[NSDictionary dictionaryWithObject:nameLabelFont forKey:NSFontAttributeName]
                                                  context:nil];
            return totalRect.size.height + PADDING_OUTER;   // >>>>>>>>>>>>>>>>>>>>>
            break;
        default:
            break;
    }
    if (ident) {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:ident];
        //NSLog(@"%@ %u %u %f, %f", ident, indexPath.section, indexPath.row, cell.frame.size.height, cell.bounds.size.height);
        return cell.frame.size.height;
    }
    return [super tableView:tableView heightForRowAtIndexPath:indexPath];
}


/* viewDidLoad */

- (void)setupDispContent
{
    int i;
    NSString* str = nil;
    

    /* KM */
    
    num_of_km = 1;
    if (_fareInfo.jrCalcKm == _fareInfo.jrSalesKm) {
        contentsForKm = [@[@{@"salesKm" : [NSString stringWithFormat:@"%@km",
                                           [RouteDataController kmNumStr:_fareInfo.totalSalesKm]]}] mutableCopy];
    } else {
        if (_fareInfo.companySalesKm != 0) {
            str = @"計算キロ(JR)";
        } else {
            str = @"計算キロ";
        }
        contentsForKm = [@[@{@"salesKm" : [NSString stringWithFormat:@"%@km",
                                           [RouteDataController kmNumStr:_fareInfo.totalSalesKm]],
                             @"calcKm": [NSString stringWithFormat:@"%@km",
                                         [RouteDataController kmNumStr:_fareInfo.jrCalcKm]],
                             @"subTitle" : str}] mutableCopy];
    }
    
    if (_fareInfo.salesKmForHokkaido != 0) {
        num_of_km++;
        if (_fareInfo.calcKmForHokkaido == _fareInfo.salesKmForHokkaido) {
            [contentsForKm addObject:@{@"title" : @"JR北海道",
                                       @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                     [RouteDataController kmNumStr:_fareInfo.salesKmForHokkaido]]}];
        } else {
            [contentsForKm addObject:@{@"title" : @"JR北海道",
                                       @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                     [RouteDataController kmNumStr:_fareInfo.salesKmForHokkaido]],
                                       @"calcKm" : [NSString stringWithFormat:@"%@km",
                                                    [RouteDataController kmNumStr:_fareInfo.calcKmForHokkaido]]}];
        }
    }
    if (_fareInfo.salesKmForKyusyu != 0) {
        num_of_km++;
        if (_fareInfo.calcKmForKyusyu == _fareInfo.salesKmForKyusyu) {
            [contentsForKm addObject:@{@"title" : @"JR九州",
                                       @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                     [RouteDataController kmNumStr:_fareInfo.salesKmForKyusyu]]}];
        } else {
            [contentsForKm addObject:@{@"title" : @"JR九州",
                                       @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                     [RouteDataController kmNumStr:_fareInfo.salesKmForKyusyu]],
                                       @"calcKm": [NSString stringWithFormat:@"%@km",
                                                   [RouteDataController kmNumStr:_fareInfo.calcKmForKyusyu]]}];
        }
    }
    if (_fareInfo.salesKmForShikoku != 0) {
        num_of_km++;
        if (_fareInfo.calcKmForShikoku == _fareInfo.salesKmForShikoku) {
            [contentsForKm addObject:@{@"title" : @"JR四国",
                                       @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                     [RouteDataController kmNumStr:_fareInfo.salesKmForShikoku]]}];
        } else {
            [contentsForKm addObject:@{@"title" : @"JR四国",
                                       @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                     [RouteDataController kmNumStr:_fareInfo.salesKmForShikoku]],
                                       @"calcKm": [NSString stringWithFormat:@"%@km",
                                                   [RouteDataController kmNumStr:_fareInfo.calcKmForShikoku]]}];
        }
    }
    if (_fareInfo.rule114_salesKm != 0) {
        num_of_km++;
        [contentsForKm addObject:@{@"title" : @"規程114条適用",
                                   @"salesKm" : [NSString stringWithFormat:@"%@km",
                                                 [RouteDataController kmNumStr:_fareInfo.rule114_salesKm]],
                                   @"calcKm": [NSString stringWithFormat:@"%@km",
                                               [RouteDataController kmNumStr:_fareInfo.rule114_calcKm]]}];
    }
    if (_fareInfo.companySalesKm != 0) {
        num_of_km++;
        [contentsForKm addObject:@{@"Company_salesKm" : [NSString stringWithFormat:@"%@km",
                                                         [RouteDataController kmNumStr:_fareInfo.companySalesKm]],
                                   @"JR_salesKm" : [NSString stringWithFormat:@"%@km",
                                                    [RouteDataController kmNumStr:_fareInfo.jrSalesKm]]}];
    }
    
    
    /* FARE */
    
    num_of_fare = 2;    /* normal + round */
    
    /* 1行目 普通＋会社 or 普通 + IC */
    /* 2行目 (往復）同上 */
    
    if (_fareInfo.isRoundtripDiscount) {
        str = @" (割引)";
    } else {
        str = @"";
    }
    
    if (_fareInfo.fareForCompanyline != 0) {
        /* 1: 普通運賃＋会社線 */
        contentsForFare = [NSMutableArray arrayWithObject:@{@"fare" : [NSString stringWithFormat:@"¥%@",
                                                                       [RouteDataController fareNumStr:_fareInfo.fareForJR + _fareInfo.fareForCompanyline]],
                                                            @"subTitle" : @"うち会社線",
                                                            @"subFare" : [NSString stringWithFormat:@"¥%@",
                                                                          [RouteDataController fareNumStr:_fareInfo.fareForCompanyline]]}];
        /* 2: 往復運賃(割引可否) ＋ 会社線往復 */
        [contentsForFare addObject:@{@"fare" : [[NSString stringWithFormat:@"¥%@",
                                                 [RouteDataController fareNumStr:_fareInfo.roundTripFareWithComapnyLine]]
                                                stringByAppendingString:str],
                                     @"subFare" : [NSString stringWithFormat:@"¥%@",
                                                   [RouteDataController fareNumStr:_fareInfo.fareForCompanyline * 2]]}];
    } else if (_fareInfo.fareForIC != 0) {
        /* 1: 普通運賃 ＋ IC運賃 */
        contentsForFare = [NSMutableArray arrayWithObject:@{@"fare" : [NSString stringWithFormat:@"¥%@",
                                                                       [RouteDataController fareNumStr:_fareInfo.fareForJR + _fareInfo.fareForCompanyline]],
                                                            @"subTitle" : @"IC運賃",
                                                            @"subFare" : [NSString stringWithFormat:@"¥%@",
                                                                          [RouteDataController fareNumStr:_fareInfo.fareForIC]]}];
        /* 2: 往復運賃 ＋ IC往復運賃 (割引無し) */
        [contentsForFare addObject:@{@"fare" : [[NSString stringWithFormat:@"¥%@",
                                                 [RouteDataController fareNumStr:_fareInfo.roundTripFareWithComapnyLine]]
                                                stringByAppendingString:str],
                                     @"subFare" : [NSString stringWithFormat:@"¥%@",
                                                   [RouteDataController fareNumStr:_fareInfo.fareForIC* 2]]}];
    } else {
        /* 1: 普通運賃 */
        contentsForFare = [NSMutableArray arrayWithObject:@{@"fare" : [NSString stringWithFormat:@"¥%@",
                                                                       [RouteDataController fareNumStr:_fareInfo.fareForJR + _fareInfo.fareForCompanyline]],
                                                            @"subTitle" : @"",
                                                            @"subFare" : @""}];
        /* 2: 往復運賃(割引可否) */
        [contentsForFare addObject:@{@"fare" : [[NSString stringWithFormat:@"¥%@",
                                                 [RouteDataController fareNumStr:_fareInfo.roundTripFareWithComapnyLine]]
                                                stringByAppendingString:str],
                                     @"subFare" : @""}];
    }
    
    /* 114 exception */
    if (_fareInfo.rule114_salesKm != 0) {
        num_of_fare++;
        [contentsForFare addObject:@{@"title" : @"規程114条適用運賃",
                                     @"fare" : [NSString stringWithFormat:@"¥%@",
                                                [RouteDataController fareNumStr:_fareInfo.rule114_fare]]}];
    }
    
    /* stock discount */
    num_of_fare += _fareInfo.availCountForFareOfStockDiscount;
    
    for (i = 0; i < _fareInfo.availCountForFareOfStockDiscount; i++) {
        [contentsForFare addObject:@{@"title" : [_fareInfo fareForStockDiscountTitle:i],
                                     @"fare" : [NSString stringWithFormat:@"¥%@",
                                                [RouteDataController fareNumStr:[_fareInfo fareForStockDiscount:i]]]}];
    }
}

///////////////////////////////////////////////
//  send mail
//
- (void)sendResultMail
{
    if (![MFMailComposeViewController canSendMail]) {
        return;
    }
    NSInteger cookedFlag;
    NSString * body =nil;
    NSString* subject = [NSString stringWithFormat:@"運賃詳細(%@ - %@)", [RouteDataController TerminalName:_fareInfo.beginStationId], [RouteDataController TerminalName:_fareInfo.endStationId]];
    
    if (!_fareInfo || _fareInfo.result != 0) {
        return;   // Error message
    }

    body = [NSString stringWithFormat:@"%@\n\n%@\n", subject, [_ds showFare:cookedFlag]];
    body = [body stringByReplacingOccurrencesOfString:@"\\" withString:@"¥"];

    // メールビュー生成
    _mailViewCtl = [[MFMailComposeViewController alloc] init];

    cookedFlag = [self retrieveCalcParameter];
    if (IS_RULE_APPLIED(cookedFlag)) {
        body = [body stringByAppendingString:@"(特例適用)\n"];
    } else {
        body = [body stringByAppendingString:@"(特例未適用)\n"];
    }
    body = [body stringByAppendingString:@"\n[指定経路]\n"];
    body = [body stringByAppendingString:[_ds routeScript]];

    _mailViewCtl.mailComposeDelegate = self;
    
    // メール本文
    [_mailViewCtl setMessageBody:body isHTML:NO];

    // メール件名
    [_mailViewCtl setSubject:subject];
#if 0
    // 添付画像
    NSData *myData = [[NSData alloc] initWithData:UIImageJPEGRepresentation([UIImage imageNamed:@"xxx.jpg"], 1)];
    [mailViewCtl addAttachmentData:myData mimeType:@"image/jpeg" fileName:@"image"];
#endif
    
    // メールビュー表示
    [self presentViewController:_mailViewCtl animated:YES completion:nil];
}




// アプリ内メーラーのデリゲートメソッド
// (メーラが終了した後に来る)
//
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result) {
        case MFMailComposeResultCancelled:
            // キャンセル
            
            break;
        case MFMailComposeResultSaved:
            // 保存 (ここでアラート表示するなど何らかの処理を行う)
            
            break;
        case MFMailComposeResultSent:
            // 送信成功 (ここでアラート表示するなど何らかの処理を行う)
            
            break;
        case MFMailComposeResultFailed:
            // 送信失敗 (ここでアラート表示するなど何らかの処理を行う)
            
            break;
        default:
            break;
    }

    [self dismissViewControllerAnimated:YES completion:nil];

    _mailViewCtl = nil;
}



- (void)showIndicate
{
    self.frontView = [[UIView alloc] initWithFrame:self.navigationController.view.bounds];
    self.frontView.backgroundColor = [UIColor clearColor];
    [self.navigationController.view addSubview:[self frontView]];
    
    self.indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    self.indicator.color = [UIColor blackColor];
    self.indicator.center = self.frontView.center;
    [self.frontView addSubview:self.indicator];
    [self.frontView bringSubviewToFront:self.indicator];
    [self.indicator startAnimating];
    
}

- (void)hideIndicate
{
    [self.indicator stopAnimating];
    [self.indicator removeFromSuperview];
    [self.frontView removeFromSuperview];
    self.indicator = nil;
    self.frontView = nil;
    
    self.navigationController.view.userInteractionEnabled = YES;
    [[self tableView] reloadData];
}


@end
