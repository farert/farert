//
//  SettingsTableViewController.h
//  FarertPre
//
//  Created by TAKEDA, Noriyuki on 2015/02/17.
//  Copyright (c) 2015年 TAKEDA, Noriyuki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsTableViewController : UITableViewController

@property NSInteger selectDbId;
@end
