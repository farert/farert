//
//  RouteSelStationSegue.h
//  FarertPre
//
//  Created by TAKEDA, Noriyuki on 2014/08/08.
//  Copyright (c) 2014年 TAKEDA, Noriyuki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteSelStationSegue : UIStoryboardSegue

@end
