//
//  AppDelegate.h
//  alps_ios
//
//  Created by TAKEDA, Noriyuki on 2014/06/09.
//  Copyright (c) 2014年 TAKEDA, Noriyuki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
}

@property (strong, nonatomic) UIWindow *window;
@property NSInteger selectTerminalId;
@property NSInteger selectLineId;
@property NSInteger context;

@end
